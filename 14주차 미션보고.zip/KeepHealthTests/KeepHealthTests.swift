//
//  KeepHealthTests.swift
//  KeepHealthTests
//
//  Created by 최용헌 on 1/6/25.
//

import Testing
@testable import KeepHealth

struct KeepHealthTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
